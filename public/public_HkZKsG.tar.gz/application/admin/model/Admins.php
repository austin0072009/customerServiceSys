<?php


namespace app\admin\model;

use think\Model;
use traits\model\SoftDelete;

/**
 * 数据模型类.
 */
class Admins extends Model
{
 
}

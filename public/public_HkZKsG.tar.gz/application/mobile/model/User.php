<?php


namespace app\mobile\model;

use think\Model;
use traits\model\SoftDelete;

/**
 * 数据模型类.
 */
class User extends Model
{

}

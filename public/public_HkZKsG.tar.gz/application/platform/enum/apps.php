<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/2/14
 * Time: 17:01
 */
namespace app\platform\enum;

class apps
{
    //当前客服系统标识
    const HJLIVE_APP_FLAG = 'HJLIVE_APP_FLAG';
    const RESET_PASSWORD_SMS_CODE_VALIDATE_COUNT = 'RESET_PASSWORD_SMS_CODE_VALIDATE_COUNT';
    const RESET_PASSWORD_SMS_CODE = 'RESET_PASSWORD_SMS_CODE';
}